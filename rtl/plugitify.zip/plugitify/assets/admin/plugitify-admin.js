(function(){"use strict";function g(s){var o=document.querySelector("[data-pty-toast]");o&&(o.textContent=s,o.hidden=!1,window.clearTimeout(g._timer),g._timer=window.setTimeout(function(){o.hidden=!0,o.textContent=""},3200))}function U(){var s=document.getElementById("pty-settings");if(!s||!window.plugitifyAdmin||!plugitifyAdmin.providers)return;var o=s.querySelector("[data-pty-provider]"),y=s.querySelector("[data-pty-model]");if(!o||!y)return;var p=s.querySelector("#plugitify-ai-api-key"),f=s.querySelector("[data-pty-password-toggle]");p&&f&&f.addEventListener("click",function(){var u=p.type==="text",d=f.querySelector(".pty-password-toggle__show"),c=f.querySelector(".pty-password-toggle__hide");p.type=u?"password":"text",f.setAttribute("aria-label",u?"نمایش کلید API":"مخفی کردن کلید API"),f.setAttribute("title",u?"نمایش کلید API":"مخفی کردن کلید API"),d&&(d.hidden=!u),c&&(c.hidden=u)});function v(u,d){var c=plugitifyAdmin.providers[u]||{},m=Object.keys(c);y.innerHTML="",m.forEach(function(b){var h=document.createElement("option");h.value=b,h.textContent=c[b],y.appendChild(h)}),d&&c[d]?y.value=d:m.length&&(y.value=m[0])}o.addEventListener("change",function(){v(o.value,"")}),v(o.value,plugitifyAdmin.currentModel||"")}document.addEventListener("DOMContentLoaded",function(){U();var s=document.getElementById("pty-dashboard");if(!s)return;document.addEventListener("click",function(t){var e=t.target.closest("[data-plugitify-delete]");if(e){var l=e.getAttribute("data-slug"),a=e.getAttribute("data-name"),i=plugitifyAdmin.strings.confirmDelete.replace("%s",a);if(window.confirm(i)){e.disabled=!0;var r=new URLSearchParams;r.set("action","plugitify_delete_plugin"),r.set("nonce",plugitifyAdmin.deleteNonce),r.set("slug",l),fetch(plugitifyAdmin.ajaxUrl,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:r.toString()}).then(function(n){return n.json()}).then(function(n){if(n&&n.success){window.location.reload();return}var T=n&&n.data&&n.data.message?n.data.message:plugitifyAdmin.strings.errorGeneric;g(T),e.disabled=!1}).catch(function(){g(plugitifyAdmin.strings.errorGeneric),e.disabled=!1})}}}),document.addEventListener("click",function(t){var e=t.target.closest("[data-plugitify-toggle]");if(e){var l=e.getAttribute("data-slug");e.disabled=!0;var a=new URLSearchParams;a.set("action","plugitify_toggle_plugin"),a.set("nonce",plugitifyAdmin.toggleNonce),a.set("slug",l),fetch(plugitifyAdmin.ajaxUrl,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:a.toString()}).then(function(i){return i.json()}).then(function(i){if(i&&i.success){window.location.reload();return}e.disabled=!1;var r=i&&i.data&&i.data.message?i.data.message:plugitifyAdmin.strings.errorGeneric;g(r)}).catch(function(){e.disabled=!1,g(plugitifyAdmin.strings.errorGeneric)})}});var o=document.getElementById("plugitify-search"),y=document.querySelectorAll("[data-plugitify-row]"),p=document.getElementById("plugitify-no-results"),f=document.querySelectorAll("[data-pty-tab]"),v="all";function u(){var t=o?o.value.trim().toLowerCase():"",e=0;Array.prototype.forEach.call(y,function(l){var a=l.getAttribute("data-status")||"",i=v==="all"||a===v,r=t===""||(l.getAttribute("data-search")||"").indexOf(t)!==-1,n=i&&r;l.hidden=!n,n&&e++}),p&&(p.hidden=e!==0||y.length===0)}Array.prototype.forEach.call(f,function(t){t.addEventListener("click",function(){v=t.getAttribute("data-pty-tab")||"all",Array.prototype.forEach.call(f,function(e){var l=e===t;e.classList.toggle("is-active",l),e.setAttribute("aria-pressed",l?"true":"false")}),u()})}),o&&o.addEventListener("input",u);var d=document.getElementById("plugitify-select-all"),c=document.querySelectorAll("[data-plugitify-bulk]"),m=document.querySelectorAll("[data-plugitify-row-checkbox]"),b=document.querySelector("[data-pty-bulk-bar]");function h(){return Array.prototype.filter.call(m,function(t){return t.checked}).map(function(t){return t.getAttribute("data-slug")})}function S(){var t=h().length>0;b&&(b.hidden=!t),Array.prototype.forEach.call(c,function(e){e.disabled=!t})}Array.prototype.forEach.call(m,function(t){t.addEventListener("change",function(){d&&!t.checked&&(d.checked=!1),S()})}),d&&d.addEventListener("change",function(){Array.prototype.forEach.call(m,function(t){var e=t.closest("[data-plugitify-row]");e&&e.hidden||(t.checked=d.checked)}),S()}),Array.prototype.forEach.call(c,function(t){t.addEventListener("click",function(){var e=t.getAttribute("data-plugitify-bulk"),l=h();if(l.length!==0&&!(e==="delete"&&!window.confirm(plugitifyAdmin.strings.confirmBulkDelete))){Array.prototype.forEach.call(c,function(i){i.disabled=!0});var a=new URLSearchParams;a.set("action","plugitify_bulk_action"),a.set("nonce",plugitifyAdmin.bulkNonce),a.set("bulk_action",e),l.forEach(function(i){a.append("slugs[]",i)}),fetch(plugitifyAdmin.ajaxUrl,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:a.toString()}).then(function(i){return i.json()}).then(function(i){if(i&&i.success){window.location.reload();return}S();var r=i&&i.data&&i.data.message?i.data.message:plugitifyAdmin.strings.errorGeneric;g(r)}).catch(function(){S(),g(plugitifyAdmin.strings.errorGeneric)})}})});var w=document.getElementById("plugitify-create-modal"),k=document.getElementById("plugitify-create-form"),q=document.querySelectorAll("[data-pty-create], #plugitify-open-create-modal");if(!w||!k||q.length===0)return;var L=document.getElementById("plugitify-plugin-name"),A=document.getElementById("plugitify-plugin-slug"),j=document.getElementById("plugitify-plugin-description"),B=document.getElementById("plugitify-create-error"),I=k.querySelector('button[type="submit"]'),x=!1;function C(t){return t.toString().trim().toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"")}function E(t){B.textContent=t,B.hidden=!1}function _(){B.hidden=!0,B.textContent=""}function G(){w.hidden=!1,document.body.classList.add("pty-modal-open"),L.focus()}function P(){w.hidden=!0,document.body.classList.remove("pty-modal-open"),k.reset(),x=!1,_(),I.disabled=!1}Array.prototype.forEach.call(q,function(t){t.addEventListener("click",G)}),Array.prototype.forEach.call(w.querySelectorAll("[data-plugitify-close]"),function(t){t.addEventListener("click",P)}),document.addEventListener("keydown",function(t){t.key==="Escape"&&!w.hidden&&P()}),L.addEventListener("input",function(){x||(A.value=C(L.value))}),A.addEventListener("input",function(){x=!0,A.value=C(A.value)}),k.addEventListener("submit",function(t){t.preventDefault(),_();var e=L.value.trim(),l=A.value.trim(),a=j.value.trim(),i=/^[a-z0-9]+(-[a-z0-9]+)*$/;if(e===""){E(plugitifyAdmin.strings.errorName);return}if(!i.test(l)){E(plugitifyAdmin.strings.errorSlug);return}if(a===""){E(plugitifyAdmin.strings.errorDescription);return}I.disabled=!0;var r=new URLSearchParams;r.set("action","plugitify_create_plugin"),r.set("nonce",plugitifyAdmin.nonce),r.set("name",e),r.set("slug",l),r.set("description",a),fetch(plugitifyAdmin.ajaxUrl,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:r.toString()}).then(function(n){return n.json()}).then(function(n){if(n&&n.success){var T=n.data&&n.data.slug?n.data.slug:A.value.trim();window.location.href=plugitifyAdmin.chatUrl+encodeURIComponent(T);return}var O=n&&n.data&&n.data.message?n.data.message:plugitifyAdmin.strings.errorGeneric;E(O),I.disabled=!1}).catch(function(){E(plugitifyAdmin.strings.errorGeneric),I.disabled=!1})})})})();
( function () {
	'use strict';

	function setTestResult( result, message, state ) {
		result.textContent = message;
		result.classList.remove( 'is-success', 'is-error', 'is-pending' );
		result.classList.add( state );
	}

	function runConnectionTest( options ) {
		var provider = options.provider;
		var model = options.model;
		var apiKey = ( options.apiKey || '' ).trim();
		var button = options.button;
		var result = options.result;
		var strings = plugitifyAdmin.strings;

		if ( ! apiKey ) {
			setTestResult( result, strings.testConnectionNoKey, 'is-error' );
			return;
		}

		if ( ! model ) {
			setTestResult( result, strings.testConnectionNoModel, 'is-error' );
			return;
		}

		var meta = ( plugitifyAdmin.providerMeta || {} )[ provider ] || {};
		var endpoint = meta.endpoint || '';
		var apiStyle = meta.apiStyle || 'chat_completions';

		var url;
		var body;

		if ( 'responses' === apiStyle ) {
			url = endpoint.replace( /\/+$/, '' ) + '/responses';
			body = {
				model: model,
				input: 'ping',
				max_output_tokens: 16,
			};
		} else {
			url = endpoint.replace( /\/+$/, '' ) + '/chat/completions';
			body = {
				model: model,
				messages: [ { role: 'user', content: 'ping' } ],
				max_tokens: 16,
			};
		}

		button.disabled = true;
		setTestResult( result, strings.testConnectionRunning, 'is-pending' );

		var controller = ( 'undefined' !== typeof AbortController ) ? new AbortController() : null;
		var timer = controller ? window.setTimeout( function () {
			controller.abort();
		}, 20000 ) : null;

		fetch( url, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + apiKey,
			},
			body: JSON.stringify( body ),
			signal: controller ? controller.signal : undefined,
		} )
			.then( function ( response ) {
				if ( timer ) {
					window.clearTimeout( timer );
				}

				if ( response.ok ) {
					setTestResult( result, strings.testConnectionSuccess, 'is-success' );
					button.disabled = false;
					return;
				}

				var status = response.status;

				return response.json().catch( function () {
					return null;
				} ).then( function ( payload ) {
					var providerMessage = payload && payload.error && payload.error.message
						? String( payload.error.message )
						: '';

					var message = strings.testConnectionUnknown;

					if ( 401 === status ) {
						message = strings.testConnectionAuth;
					} else if ( 403 === status ) {
						message = strings.testConnectionForbidden;
					} else if ( 404 === status ) {
						message = strings.testConnectionNotFound;
					} else if ( 429 === status ) {
						message = strings.testConnectionRate;
					} else if ( status >= 500 ) {
						message = strings.testConnectionServer;
					} else if ( 400 === status ) {
						message = strings.testConnectionBadRequest;
					}

					if ( providerMessage ) {
						message += ' (' + providerMessage + ')';
					}

					setTestResult( result, message, 'is-error' );
					button.disabled = false;
				} );
			} )
			.catch( function ( error ) {
				if ( timer ) {
					window.clearTimeout( timer );
				}

				var message = ( error && 'AbortError' === error.name )
					? strings.testConnectionTimeout
					: strings.testConnectionNetwork;

				setTestResult( result, message, 'is-error' );
				button.disabled = false;
			} );
	}

	document.addEventListener( 'DOMContentLoaded', function () {
		var root = document.getElementById( 'pty-settings' );

		if ( ! root || ! window.plugitifyAdmin ) {
			return;
		}

		var providerSelect = root.querySelector( '[data-pty-provider]' );
		var modelSelect = root.querySelector( '[data-pty-model]' );
		var apiKeyInput = root.querySelector( '#plugitify-ai-api-key' );
		var testButton = root.querySelector( '[data-pty-test-connection]' );
		var testResult = root.querySelector( '[data-pty-test-connection-result]' );

		if ( ! providerSelect || ! modelSelect || ! apiKeyInput || ! testButton || ! testResult ) {
			return;
		}

		testButton.addEventListener( 'click', function () {
			runConnectionTest( {
				provider: providerSelect.value,
				model: modelSelect.value,
				apiKey: apiKeyInput.value,
				button: testButton,
				result: testResult,
			} );
		} );
	} );
}() );

(function(){"use strict";function a(n){return navigator.clipboard&&window.isSecureContext?navigator.clipboard.writeText(n):new Promise(function(e,o){var t=document.createElement("textarea");t.value=n,t.setAttribute("readonly",""),t.style.position="fixed",t.style.top="-1000px",document.body.appendChild(t),t.select();var i=!1;try{i=document.execCommand("copy")}catch{i=!1}document.body.removeChild(t),i?e():o()})}function c(){var n=document.querySelectorAll("[data-pty-copy]");Array.prototype.forEach.call(n,function(e){var o=e.textContent;e.addEventListener("click",function(){a(e.getAttribute("data-pty-copy")).then(function(){e.textContent="کپی شد",e.classList.add("is-copied"),window.setTimeout(function(){e.textContent=o,e.classList.remove("is-copied")},2e3)}).catch(function(){e.textContent="کپی نشد، دستی انتخاب کنید",window.setTimeout(function(){e.textContent=o},2600)})})})}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",c):c()})();
